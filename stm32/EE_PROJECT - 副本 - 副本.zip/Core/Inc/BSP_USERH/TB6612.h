#ifndef _TB6612_H
#define _TB6612_H

void Load(int moto1,int moto2);
void TB6612_Init();

#endif
